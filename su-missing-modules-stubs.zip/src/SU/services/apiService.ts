// Lightweight stubs so the app compiles. Replace with your real API calls.
export async function apiGetUserPhotos() { return []; }
export async function apiUploadPhoto() { return { ok: true }; }
export async function apiDeletePhoto() { return { ok: true }; }
export async function apiUpdatePhotoPublicStatus() { return { ok: true }; }
export async function apiReplacePhoto() { return { ok: true }; }
export async function apiDeleteComment() { return { ok: true }; }
export async function apiSendPhoto() { return { ok: true }; }
export async function apiGetAllUsers() { return []; }
export async function apiGetNotifications() { return []; }
export async function apiGetPendingPhotoShares() { return []; }
export async function apiUpdatePhotoShareStatus() { return { ok: true }; }
export async function apiGetSentShares() { return []; }
export async function apiGetConversation() { return []; }
