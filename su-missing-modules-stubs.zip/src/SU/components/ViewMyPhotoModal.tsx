import React from 'react';
type Props = {};
const ViewMyPhotoModal: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="ViewMyPhotoModal">{children}</div>
);
export default ViewMyPhotoModal;
