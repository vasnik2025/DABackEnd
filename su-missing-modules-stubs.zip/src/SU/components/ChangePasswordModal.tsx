import React from 'react';
type Props = {};
const ChangePasswordModal: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="ChangePasswordModal">{children}</div>
);
export default ChangePasswordModal;
