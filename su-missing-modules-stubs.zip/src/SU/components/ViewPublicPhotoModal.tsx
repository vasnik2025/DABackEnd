import React from 'react';
type Props = {};
const ViewPublicPhotoModal: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="ViewPublicPhotoModal">{children}</div>
);
export default ViewPublicPhotoModal;
