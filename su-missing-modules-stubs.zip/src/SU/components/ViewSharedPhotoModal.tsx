import React from 'react';
type Props = {};
const ViewSharedPhotoModal: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="ViewSharedPhotoModal">{children}</div>
);
export default ViewSharedPhotoModal;
