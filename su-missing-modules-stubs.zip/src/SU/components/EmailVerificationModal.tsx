import React from 'react';
type Props = {};
const EmailVerificationModal: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="EmailVerificationModal">{children}</div>
);
export default EmailVerificationModal;
