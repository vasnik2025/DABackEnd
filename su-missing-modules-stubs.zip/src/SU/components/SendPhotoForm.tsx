import React from 'react';
type Props = {};
const SendPhotoForm: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="SendPhotoForm">{children}</div>
);
export default SendPhotoForm;
