import React from 'react';
type Props = {};
const PhotoGrid: React.FC<Props> = ({ children, ...props }) => (
  <div data-stub="PhotoGrid">{children}</div>
);
export default PhotoGrid;
